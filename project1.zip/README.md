# Telecom Customer Churn Prediction Project

## Overview
This project predicts customer churn for a telecom company using machine learning. 
It follows a structured ML pipeline including data loading, preprocessing, model training, and evaluation.

## Structure
- `report/` : Contains the detailed project report (PDF).
- `data/` : Contains the dataset file.
- `src/` : Contains Python source code for ML pipeline, training, deployment, and dashboard.
- `artifacts/` : Contains trained model files.
- `figures/` : Contains plots (EDA, heatmap, confusion matrix, etc.).

## How to Run
1. Install dependencies: `pip install -r requirements.txt`
2. Run the ML pipeline: `python src/churn_pipeline.py`
3. To deploy as Flask app: `python src/app.py`
4. To view dashboard: `streamlit run src/dashboard.py`
