import streamlit as st
import pandas as pd
import seaborn as sns
import matplotlib.pyplot as plt

st.title("Telecom Customer Churn Dashboard")

df = pd.read_csv("data/telecom_churn_synthetic.csv")
st.write("### Dataset Preview")
st.dataframe(df.head())

st.write("### Churn Distribution")
fig, ax = plt.subplots()
sns.countplot(x="Churn", data=df, ax=ax)
st.pyplot(fig)

st.write("### Correlation Heatmap")
df_num = df.select_dtypes(include=['float64', 'int64'])
fig, ax = plt.subplots(figsize=(8,6))
sns.heatmap(df_num.corr(), annot=True, cmap="coolwarm", ax=ax)
st.pyplot(fig)
